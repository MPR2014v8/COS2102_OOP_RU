#include <iostream>
using namespace std;

class Size
{
	private :

		double width;
		double height;

	public :

		Size()
		{
			width = 1;
			height = 1;
		}

		void setWidth(double i)
		{
			width = i;
		}

		void setHeight(double i)
		{
			height = i;
		}

		double getWidth()
		{
			return width;
		}

		double getHeight()
		{
			return height;
		}

};

class Appliance
{
	private :

		int year;
		double price;

	public :

		Appliance()
		{
			year = 1;
			price = 1;
		}

		Appliance(int y, double p)
		{
			year = y;
			price = p;
		}

		~Appliance()
		{
			cout<<"year = "<<year<<endl;
			cout<<"price = "<<price<<endl;
		}

		void setYear(int i)
		{
			year = i;
		}

		void setPrice(double i)
		{
			price = i;
		}

		int getYear()
		{
			return year;
		}

		double getPrice()
		{
			return price;
		}

		virtual void show()
		{
			cout<<"year = "<<year<<endl;
			cout<<"price = "<<price<<endl;
		}

		virtual void print(ostream& os)
		{
			os<<"year = "<<year<<endl;
			os<<"price = "<<price<<endl;
		}

		Appliance(Appliance& c)
		{
			year = c.year;
			price = c.price;
		}

		Appliance& operator = (Appliance& c)
		{
			year = c.year;
			price = c.price;

			return *this;
		}

		friend ostream& operator << (ostream& os, Appliance& r);

};

ostream& operator << (ostream& os, Appliance& r)
{
	r.print(os);
	return os;
}

class Fridge : public Appliance
{
	private :

		double capacity;
		int door;
		static int Obj;

	public :

		Fridge()
		{
			capacity = 1;
			door = 1;
			++Obj;
		}

		Fridge(int y, double p, double c, int d): Appliance(y, p)
		{
			capacity = c;
			door = d;
			++Obj;
		}

		~Fridge()
		{
			cout<<"capacity = "<<capacity<<endl;
			cout<<"door = "<<door<<endl;
			cout<<"Obj = "<<Obj<<endl;
			--Obj;
		}

		void setCapacity(double i)
		{
			capacity = i;
		}

		void setDoor(int i)
		{
			door = i;
		}

		double getCapacity()
		{
			return capacity;
		}

		int getDoor()
		{
			return door;
		}

		static int getObj()
		{
			return Obj;
		}

		Fridge& operator = (Fridge& c)
		{
			setYear( c.getYear() );
			setPrice( c.getPrice() );
			capacity = c.capacity;
			door = c.door;
			Obj = c.Obj;

			return *this;
		}

		Fridge(Fridge& c)
		{
			setYear( c.getYear() );
			setPrice( c.getPrice() );
			capacity = c.capacity;
			door = c.door;
			Obj = c.Obj;
		}

		void show()
		{
			cout<<"year = "<<getYear()<<endl;
			cout<<"price = "<<getPrice()<<endl;
			cout<<"capacity = "<<capacity<<endl;
			cout<<"door = "<<door<<endl;
			cout<<"Obj = "<<Obj<<endl;
		}

		void print(ostream& os)
		{
			os<<"year = "<<getYear()<<endl;
			os<<"price = "<<getPrice()<<endl;
			os<<"capacity = "<<capacity<<endl;
			os<<"door = "<<door<<endl;
			os<<"Obj = "<<Obj<<endl;
		}

};
int Fridge::Obj;

class Microwave : public Appliance
{
	private :

		double capacity;
		bool grill;

	public :

		Microwave()
		{
			capacity = 1;
			grill = false;
		}

		Microwave(int y, double p, double c, bool g): Appliance(y, p)
		{
			capacity = c;
			grill = g;
		}

		~Microwave()
		{
			cout<<"capacity = "<<capacity<<endl;
			cout<<"grill = "<<grill<<endl;
		}

		void setCapacity(double i)
		{
			capacity = i;
		}

		void setGrill(bool i)
		{
			grill = i;
		}

		double getCapacity()
		{
			return capacity;
		}

		bool getGrill()
		{
			return grill;
		}

		Microwave& operator = (Microwave& c)
		{
			setYear(c.getYear());
			setPrice(c.getPrice());
			capacity = c.capacity;
			grill = c.grill;

			return *this;
		}

		Microwave(Microwave& c)
		{
			setYear(c.getYear());
			setPrice(c.getPrice());
			capacity = c.capacity;
			grill = c.grill;
		}

		void show()
		{
			cout<<"year = "<<getYear()<<endl;
			cout<<"price = "<<getPrice()<<endl;
			cout<<"capacity = "<<capacity<<endl;
			cout<<"grill = "<<grill<<endl;
		}

		void print(ostream& os)
		{
			os<<"year = "<<getYear()<<endl;
			os<<"price = "<<getPrice()<<endl;
			os<<"capacity = "<<capacity<<endl;
			os<<"grill = "<<grill<<endl;
		}

		void operator () (double i)
		{
			capacity = i;
		}

		void operator [] (bool i)
		{
			grill = i;
		}

		friend void operator ! (Microwave& r);
};

void operator ! (Microwave& r)
{
	if (r.grill == true)
	{
		r.grill = false;
	}else
	if(r.grill == false)
	{
		r.grill = true;
	}
}

class Stove : public Appliance
{
	private :

		int type;
		int head;

	public :

		Stove()
		{
			type = 1;
			head = 1;
		}

		Stove(int y, double p, int t, int h): Appliance(y, p)
		{
			type = t;
			head = h;
		}

		~Stove()
		{
			cout<<"type = "<<type<<endl;
			cout<<"head = "<<head<<endl;
		}

		void setType(int i)
		{
			type = i;
		}

		void setHead(int i)
		{
			head = i;
		}

		int getType()
		{
			return type;
		}

		int getHead()
		{
			return head;
		}

		void show()
		{
			cout<<"year = "<<getYear()<<endl;
			cout<<"price = "<<getPrice()<<endl;
			cout<<"type = "<<type<<endl;
			cout<<"head = "<<head<<endl;
		}

		void print(ostream& os)
		{
			os<<"year = "<<getYear()<<endl;
			os<<"price = "<<getPrice()<<endl;
			os<<"type = "<<type<<endl;
			os<<"head = "<<head<<endl;
		}

		Stove& operator = (Stove& c)
		{
			setYear( c.getYear() );
			setPrice( c.getPrice() );
			type = c.type;
			head = c.head;

			return *this;
		}

		Stove(Stove& c)
		{
			setYear( c.getYear() );
			setPrice( c.getPrice() );
			type = c.type;
			head = c.head;
		}

		friend void operator ++ (Stove& r);
};

void operator ++ (Stove& r)
{
	if(r.head < 5) r.head = r.head + 1;
}

class Kitchen
{
	private :

		Size size;
		int num;
		static int count;
		Appliance **item;

	public :

		Kitchen()
		{
			size.setWidth(1); 
			size.setHeight(1);
			num = 5;
			item = new Appliance*[num];
		}

		Kitchen(double w, double h, int n)
		{
			size.setWidth(w); 
			size.setHeight(h);
			num = n;
			item = new Appliance*[num];
		}

		~Kitchen()
		{
			cout<<"width = "<<size.getWidth()<<endl;
			cout<<"height = "<<size.getHeight()<<endl;
			cout<<"num = "<<num<<endl;

			for (int i = 0; i < num; ++i)
			{
				cout<<*item[i]<<endl;
			}
			delete [] item;
		}

		void setWidth(double w)
		{
			size.setWidth(w);
		}

		void setHeight(double h)
		{
			size.setHeight(h);
		}

		void setNum(int i)
		{
			delete [] item;

			num = i;
			item = new Appliance*[num];
		}

		void setItem(int i, Appliance* r)
		{
			item[i] = r;
		}

		double getWidth()
		{
			return size.getWidth();
		}

		double getHeight()
		{
			return size.getHeight();
		}

		int getNum()
		{
			return num;
		}

		Appliance& getItem(int i)
		{
			return *item[i];
		}

		void addItem(Appliance * r)
		{
			if(count < num) item[count] = r;
			count++;
		}

};

int Kitchen::count;

int main()
{
	Fridge a(2519, 29999, 25.1, 2), a1;
	Microwave b(2518, 3500, 23, true), b1;
	Stove c(2518, 25000, 2, 3), c1;

	a1 = a;
	b1 = b;
	c1 = c;

	Kitchen myKitchen(5, 6, 3);
	myKitchen.setItem(0, &a);
	myKitchen.setItem(1, &b);
	myKitchen.setItem(2, &c);

	c.setHead(5);

	Microwave d;
	d.setYear(2519); 
	d.setPrice(6000);
	d.setCapacity(30);
	d.setGrill(false);

	myKitchen.setNum(4);
	myKitchen.setItem(0, &a);
	myKitchen.setItem(1, &b);
	myKitchen.setItem(2, &c);
	myKitchen.setItem(3, &d);

	cout<<"///show myKitchen"<<endl;
	int total = 0;

	for (int i = 0; i < myKitchen.getNum(); ++i)
	{
		cout<<"//myKitchen ["<<i<<"]"<<endl;
		cout<<myKitchen.getItem(i);
		total += myKitchen.getItem(i).getPrice();
	}

	cout<<"total = "<<total<<endl;

	cout<<endl;
	cout<<"//End"<<endl;


	return 0;
}